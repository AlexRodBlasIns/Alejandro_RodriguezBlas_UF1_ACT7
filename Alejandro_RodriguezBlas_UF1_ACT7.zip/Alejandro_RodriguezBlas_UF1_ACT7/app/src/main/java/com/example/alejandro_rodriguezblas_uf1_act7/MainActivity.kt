package com.example.alejandro_rodriguezblas_uf1_act7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var confirmButton: Button
    lateinit var username: EditText
    lateinit var password: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        confirmButton = findViewById(R.id.button)
        username = findViewById(R.id.editTextText)
        password = findViewById(R.id.editTextTextPassword)

        confirmButton.setOnClickListener{
            val duration = Toast.LENGTH_LONG
            val toast = Toast.makeText(this, username.text.toString() + " " + password.text.toString(),duration)
            toast.show()

            Log.d("Informacion",username.text.toString() + " " + password.text.toString())
        }

    }
}